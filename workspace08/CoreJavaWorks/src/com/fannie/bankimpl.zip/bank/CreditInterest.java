package com.fannie.bank;

public interface CreditInterest extends Interest {
	public void addMonthlyInt();
	public void addHalfYrlyInt();
	public void addAnnualInt();

}
