package com.fannie.bank;

public interface Interest {
	double intPct =0;
	double fixDeptAct =0;
	double pLoanAct =0;
	double hLoanAct =0;
	public double calcInt();
}
